package TNTFC;

import java.util.Scanner;
public class Assignment implements AssignmentInterface{
    String name;
    double weight;
    double actualGrade;

    Scanner scan = new Scanner(System.in);

    public Assignment (String name, double weight, double grade){
        this.name = name;
        this.weight = weight;
        this.actualGrade = grade;
    }

    public String getName(){
        return this.name;
    }

    public double getWeight(){
        return this.weight;
    }

    public String getFormattedGrade(){
        String result = String.valueOf(actualGrade);
        result += "/";
        result += String.valueOf(weight);
        double percentage = actualGrade/weight;
        result += " ";
        result += String.valueOf(percentage);
        result += "%";
        return result;
    }

    public double getGrade(){
        return this.actualGrade/this.weight;
    }

    public String displayAssignment(){
        String result = ("\n\t\t" + this.name + " weight: " + this.weight + " grade: " + this.actualGrade);
        return result;
    }

    public void editActualGrade() {
        System.out.println("This assignment is worth " + this.getWeight() + " points. How many points did you earn?");
        actualGrade = scan.nextInt();
        scan.nextLine();
        double percentageGrade = 100*(actualGrade/this.getWeight());
        System.out.println("You earned " + actualGrade + "/" + this.getWeight() + " for a percent grade of: " + percentageGrade + "%");
    }

}