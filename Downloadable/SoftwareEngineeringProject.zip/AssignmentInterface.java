package TNTFC;

public interface AssignmentInterface {
    public String getName();
    public double getWeight();
    public String getFormattedGrade();
    public double getGrade();
    public String displayAssignment();
    public void editActualGrade();
}