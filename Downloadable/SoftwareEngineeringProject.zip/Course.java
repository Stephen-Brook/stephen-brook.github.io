package TNTFC;
import java.util.HashMap;
import java.util.Scanner;
public class Course implements CourseInterface{

    String name;
    double overallGrade;
    double roundedPercentage;
    Scanner scan = new Scanner(System.in);
    HashMap<String, Category> categories = new HashMap<>();

    public Course(String name, double roundedPercentage){
        this.name = name;
        this.roundedPercentage = roundedPercentage;
        this.overallGrade = calculateActualGrade();
    }

    public String getName() {
        return name;
    }

    public double getActualGrade() {
        return this.calculateActualGrade();
    }

    public String getLetterGrade(double overallGrade) {
        if(overallGrade >= 93.00){
            return("A");
        }
        if(overallGrade >= 90.00){
            return("A-");
        }
        if(overallGrade >= 87.00){
            return("B+");
        }
        if(overallGrade >= 83.00){
            return ("B");
        }
        if(overallGrade >= 80.00){
            return("B-");
        }
        if(overallGrade >= 77.00){
            return("C+");
        }
        if(overallGrade >= 73.00){
            return("C");
        }
        if(overallGrade >= 70.00){
            return("C-");
        }
        if(overallGrade >= 67.00){
            return("D+");
        }
        if(overallGrade >= 63.00){
            return("D");
        }
        if(overallGrade >= 60.00){
            return("D-");
        }
        else{
            return("F");
        }
    }
    //displays incorrect letter grade
    public void round(){
        double grade = calculateActualGrade(); // Ensure overallGrade is up-to-date
        grade += this.roundedPercentage; // Add roundedPercentage to overallGrade
        System.out.println(this.name + ", percent grade: " + grade + "%, letter grade: " + this.getLetterGrade(this.calculateActualGrade()+this.roundedPercentage));
        for(Category c : categories.values()){
            System.out.println(c.displayCategory());
        }
    }
    //displays incorrect letter grade
    public String displayCourse() {
        String result = this.name + ", percent grade: " + this.calculateActualGrade() + "%, letter grade: " + this.getLetterGrade(this.calculateActualGrade()) + "\n";
        for (Category c : this.categories.values()) {
            result += "\t" + c.displayCategory() + "\n"; // Ensure each category starts on a new line.
        }
        return result;
    }

    public void addCategory(Category c) {
        this.categories.put(c.getName(), c);
    }

    public void addCategories(){
        System.out.println("How many categories would you like to add to " + this.name + "?");
        int categoryNum = scan.nextInt();
        scan.nextLine();
        for(int i = 0; i < categoryNum; i++){
            System.out.println("Enter category " + i + " name: ");
            String categoryName = scan.nextLine();
            System.out.println("Enter " + categoryName + " weight: ");
            double categoryWeight = scan.nextDouble();
            scan.nextLine();
            Category category = new Category(categoryName, categoryWeight);
            this.categories.put(categoryName, category);
        }
        System.out.println("Your updated course is: ");
        System.out.println(this.displayCourse());
    }

    public void editCategories(){
        for(Category c : categories.values()){
            System.out.println(c.displayCategory());
        }
        System.out.println("Which cagtegory would you like to edit?");
        String editCategory = scan.nextLine();
        if(categories.containsKey(editCategory)){
            Category category = categories.get(editCategory);
            String input;
            do {
                System.out.println("\nEditing Category: " + editCategory);
                System.out.println(category.displayCategory());
                System.out.println("1 - Input Assignments");
                System.out.println("2 - Edit Assignment Grades");
                System.out.println("3 - Edit Potential Assignment Grades");
                System.out.println("r - return to menu");
                input = scan.nextLine();
                switch (input) {
                    case "1":
                        inputAssignments(category);
                        break;
                    case "2":
                        editGrades(category);
                        break;
                    case "3":
                        potentialGrade(category);
                        break;
                    case "r":
                        break;
                    default:
                        System.out.println("Invalid option, please try again");
                }
            }while (!input.equals("r"));
        }
        else{
            System.out.println("Invalid input");
        }
    }

    public void inputAssignments(Category category){
        this.categories.get(category.getName()).addAssignments();
    }

    public void editGrades(Category category){
        this.categories.get(category.getName()).editAssignmentGrades();
    }

    public void potentialGrade(Category potentialCategory) {
        double potentialCategoryGrade = this.categories.get(potentialCategory.getName()).editPotentialAssignmentGrades();
        System.out.println("Category grade: " + potentialCategoryGrade + "%");
        double totalPointsPossible = 0;
        double totalPointsEarned = 0;
        for (Category c : this.categories.values()) {
            double categoryPointsPossible = 0;
            double categoryPointsEarned = 0;
            if (c.getName().equals(potentialCategory.getName())) {
                categoryPointsEarned = potentialCategoryGrade * c.getWeight();
                categoryPointsPossible = c.getWeight();
            } else {
                for (Assignment assignment : c.assignments.values()) {
                    categoryPointsEarned += assignment.getGrade() * assignment.getWeight();
                    categoryPointsPossible += assignment.getWeight();
                }
            }
            double categoryPercentage = (categoryPointsPossible > 0) ? (categoryPointsEarned / categoryPointsPossible) : 0;
            totalPointsEarned += categoryPercentage * c.getWeight();
            totalPointsPossible += c.getWeight();
        }
        double predictedGrade = (totalPointsPossible > 0) ? (totalPointsEarned / totalPointsPossible) : 0;
        System.out.println("\nHere is your predicted final grade, this will not save: ");
        System.out.println(this.name + ", percent grade: " + predictedGrade + "%, letter grade: " + this.getLetterGrade(predictedGrade));
    }

    public double calculateActualGrade(){
        double totalPointsEarned = 0.0;
        double totalPointsPossible = 0.0;
        for(Category category : this.categories.values()){
            double categoryPointsEarned = 0.0;
            double categoryPointsPossible = 0.0;
            for(Assignment assignment : category.assignments.values()){
                categoryPointsEarned += assignment.getGrade() * assignment.getWeight();
                categoryPointsPossible += assignment.getWeight();
            }
            double categoryPercentage = (categoryPointsPossible > 0) ? (categoryPointsEarned / categoryPointsPossible) : 0;
            totalPointsEarned += categoryPercentage * category.getWeight();
            totalPointsPossible += category.getWeight();
        }
        return (totalPointsPossible > 0) ? (totalPointsEarned / totalPointsPossible) * 100 : 0;
    }

}