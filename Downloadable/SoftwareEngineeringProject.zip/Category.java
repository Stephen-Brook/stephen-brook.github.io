package TNTFC;
import java.util.HashMap;
import java.util.Scanner;
public class Category implements CategoryInterface {

    String name;
    double weight;
    HashMap<String, Assignment> assignments = new HashMap<>();
    Scanner scan = new Scanner(System.in);

    public Category (String name, double weight){
        this.name = name;
        this.weight = weight;
    }

    public String getName() {
        return name;
    }

    public double getWeight() {
        return this.weight;
    }

    public String displayCategory() {
        String result = this.name + " weight: " + this.weight + "%";
        for (Assignment a : this.assignments.values()) {
            result += "\t\t" + a.displayAssignment();
        }
        return result;
    }


    public String displayAllAssignments() {
        String result = "";
        for(String s : assignments.keySet()){
            result += (assignments.get(s).displayAssignment());
        }
        return result;
    }

    public void addAssignment(Assignment assignment) {
        this.assignments.put(assignment.getName(), assignment);
    }

    public void addAssignments() {
        System.out.println("How many assignments would you like to add to category " + this.name + "?");
        int assignmentNum = scan.nextInt();
        scan.nextLine();
        for(int i = 0; i < assignmentNum; i++){
            System.out.println("Enter assignment " + i + " name: ");
            String assignmentName = scan.nextLine();
            System.out.println("Enter " + assignmentName + " weight: ");
            double assignmentWeight = scan.nextDouble();
            scan.nextLine();
            System.out.println("Has this assignment been graded?(y/n)");
            String beenGraded = scan.nextLine();
            double grade = 0.0;
            if(beenGraded.equals("y")){
                System.out.println("This assignment is worth: " + assignmentWeight + " points. How many points did you earn?");
                grade = scan.nextDouble();
                scan.nextLine();
            }
            if(beenGraded.equals("n")){
                System.out.println("The assignment has not been graded, and will be calculated as a 0 until input is provided.");
            }
            else if(!beenGraded.equals("y") && !beenGraded.equals("n")){
                System.out.println("Invalid Input");
            }
            Assignment assignment = new Assignment(assignmentName, assignmentWeight, grade);
            this.assignments.put(assignmentName, assignment);
        }
        System.out.println("Your updated category is: ");
        System.out.println(this.displayCategory());
    }

    public void editAssignmentGrades() {
        System.out.println("Assignment List: ");
        System.out.println(this.displayAllAssignments());
        System.out.println("Which assignment would you like to edit?");
        String editAssignment = scan.nextLine();
        if (assignments.containsKey(editAssignment)) {
            assignments.get(editAssignment).editActualGrade();
        } else {
            System.out.println("Invalid input"); // This catches invalid assignment names
        }
    }

    public double editPotentialAssignmentGrades() {
        double result = 0;
        System.out.println("Assignment List: ");
        System.out.println(this.displayAllAssignments());
        System.out.println("Does the assignment you want to predict already exist?(y/n)");
        String exists = scan.nextLine();
        if(exists.equals("y")){
            System.out.println("Enter the name of the assignment you want to predict: ");
            String assignmentName = scan.nextLine();
            if(assignments.containsKey(assignmentName)){
                System.out.println(assignmentName + " is worth " + assignments.get(assignmentName).getWeight() + " points, enter the grade you predict you will earn");
                double grade = scan.nextDouble();
                scan.nextLine();
                double possiblePoints = 0;
                double earnedPoints = 0;
                for(Assignment assignment : assignments.values()){
                    if(assignment.getName().equals(assignmentName)){
                        possiblePoints += assignment.getWeight();
                        earnedPoints += grade;
                    }
                    else if(!assignment.getName().equals(assignmentName)){
                        possiblePoints += assignment.getWeight();
                        earnedPoints += (assignment.getGrade())*assignment.getWeight();
                    }
                }
                result = 100*(earnedPoints/possiblePoints);
            }
            else{
                System.out.println("Invalid input");
            }
        }
        else if(exists.equals("n")){
            System.out.println("Enter the name of the assignment you want to predict: ");
            String assignmentName = scan.nextLine();
            System.out.println("Enter the weight of the assignment you want to predict: ");
            double assignmentWeight = scan.nextDouble();
            scan.nextLine();
            System.out.println(assignmentName + " is worth: " + assignmentWeight + " points, enter the grade tou predict you will earn");
            double grade = scan.nextDouble();
            scan.nextLine();
            double percentageGrade = (grade/assignmentWeight)*100;
            System.out.println("Your predicted score is " + grade + "/" + assignmentWeight + " points, or " + percentageGrade + "%");
            double possiblePoints = 0;
            double earnedPoints = 0;
            for(Assignment assignment : assignments.values()){
                possiblePoints += assignment.getWeight();
                earnedPoints += assignment.getGrade()*assignment.getWeight();
            }
            possiblePoints += assignmentWeight;
            earnedPoints += grade;
            result = 100*(earnedPoints/possiblePoints);
        }
        if(!exists.equals("y") && !exists.equals("n")){
            System.out.println("Invalid Input");
        }
        return result;
    }

}