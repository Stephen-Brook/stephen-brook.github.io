package TNTFC;

import java.io.*;
import java.util.Scanner;

public class CourseFileManager implements Observer {
    private Calculator calculator;
    Scanner scan = new Scanner(System.in);

    public CourseFileManager(Calculator calculator) {
        this.calculator = calculator;
        this.calculator.addObserver(this);
    }

    public void update() {
        saveCourses();
    }

    public String dataParser(){
        String result = "";
        for(Course course : calculator.courses.values()){
            result += "Course :: " + course.getName() + " :: " + course.getActualGrade() + " :: " + course.getLetterGrade(course.getActualGrade()) + " :: " + course.roundedPercentage + "\n" ;
            for(Category category : course.categories.values()){
                result += "Category :: " + category.getName() + " :: " + category.getWeight() + "\n";
                for(Assignment assignment : category.assignments.values()){
                    result += "Assignment :: " + assignment.getName() + " :: " + assignment.getWeight() + " :: " + assignment.getGrade() + "\n";
                }
            }
        }
        return result;
    }

    public void saveCourses() {
        try (PrintWriter out = new PrintWriter(new FileOutputStream("courses.txt"))) {
            String result = dataParser();
            out.println(dataParser());
        } catch (IOException e) {
            System.err.println("Error saving courses: " + e.getMessage());
        }
    }

    public void loadCourses() {
        try (BufferedReader reader = new BufferedReader(new FileReader("courses.txt"))) {
            String line;
            Course currentCourse = null;
            Category currentCategory = null;

            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(" :: ");
                switch (parts[0]) {
                    case "Course":
                        currentCourse = new Course(parts[1], Double.parseDouble(parts[4]));
                        calculator.addCourse(currentCourse);
                        break;
                    case "Category":
                        if (currentCourse != null) {
                            currentCategory = new Category(parts[1], Double.parseDouble(parts[2]));
                            currentCourse.addCategory(currentCategory);
                        }
                        break;
                    case "Assignment":
                        if (currentCategory != null) {
                            Assignment assignment = new Assignment(parts[1], Double.parseDouble(parts[2]), Double.parseDouble(parts[3])*Double.parseDouble(parts[2]));
                            currentCategory.addAssignment(assignment);
                        }
                        break;
                }
            }
            for(Course course : calculator.courses.values()){
                course.calculateActualGrade();
            }
        }
        catch (IOException e) {
            System.err.println("Error loading courses: " + e.getMessage());
        }
    }

}