package TNTFC;

public interface CalculatorInterface {
    public void addCourse(Course c);
    public void newCourse();
    public void deleteCourse(Course c);
    public String displayCourse(Course c);
    public String displayAllCourses();
    public void editCourse();
    public void inputCategory(Course c);
    public void inputCategoryAssignmentInfo(Course c);
    public void addObserver(Observer o);
    public void removeObserver(Observer o);
    public void notifyObservers();
}