package TNTFC;
import java.util.Scanner;
public class Main {

    static Calculator calculator = new Calculator();
    static Scanner scan = new Scanner(System.in);
    static CourseFileManager fileManager = new CourseFileManager(calculator);

    public static void main(String[] args) {
        String input;

        loadData();

        do {
            System.out.println(calculator.displayAllCourses());
            System.out.println("Options:");
            System.out.println("1 - Input a new course");
            System.out.println("2 - Edit a course");
            System.out.println("3 - Delete a course");
            System.out.println("4 - Round All Courses");
            System.out.println("s - Save");
            System.out.println("q - Quit");
            input = scan.nextLine();
            switch (input) {
                case "1":
                    newCourse();
                    break;
                case "2":
                    editCourse();
                    break;
                case "3":
                    deleteCourse();
                    break;
                case "4":
                    roundCourses();
                    break;
                case "s":
                    save();
                    break;
                case "q":
                    quit();
                    break;
                default:
                    System.out.println("Invalid option, please try again");
            }
        } while (!input.equals("q"));
    }

    private static void newCourse() {
        calculator.newCourse();
    }

    public static void editCourse(){
        calculator.editCourse();
    }

    public static void deleteCourse(){
        System.out.println("Which course would you like to delete?");
        calculator.displayAllCourses();
        String input = scan.nextLine();
        if(calculator.courses.containsKey(input)){
            Course c = calculator.courses.get(input);
            calculator.courses.remove(input);
        }
        else{
            System.out.println("Invalid input");
        }
    }

    public static void roundCourses(){
        System.out.println("\nRounded Courses, this information will not save");
        for(String c : calculator.courses.keySet()){
            calculator.courses.get(c).round();
        }
    }

    public static void save(){
        System.out.println("\nSaving courses...");
        fileManager.saveCourses();
    }

    public static void quit(){
        save();
        System.out.println("Quitting...");
    }

    public static void loadData(){
        String input;
        System.out.println("Would you like to load saved progress?(y/n)");
        input = scan.nextLine();
        switch (input) {
            case "y":
                load();
                break;
            case "n":
                System.out.println("Creating a new calculator...");
                break;
            default:
                System.out.println("Invalid input" + "\n" + "Creating a new calculator...");
        }
    }

    public static void load(){
        System.out.println("Loading courses...");
        fileManager.loadCourses();
        calculator.displayAllCourses();
    }

}