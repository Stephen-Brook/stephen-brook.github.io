package TNTFC;

public interface CourseInterface {
    public String getName();
    public double getActualGrade();
    public double calculateActualGrade();
    public String getLetterGrade(double grade);
    public void round();
    public String displayCourse();
    public void addCategory(Category c);
    public void addCategories();
    public void editCategories();
    public void inputAssignments(Category c);
    public void editGrades(Category c);
    public void potentialGrade(Category c);
}