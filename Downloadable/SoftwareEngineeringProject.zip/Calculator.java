package TNTFC;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Scanner;
public class Calculator implements CalculatorInterface {

    HashMap<String, Course> courses = new HashMap<>();
    Scanner scan = new Scanner(System.in);
    private List<Observer> observers = new ArrayList<>();

    public void addCourse(Course course) {
        courses.put(course.getName(), course);
        notifyObservers();
    }

    public void newCourse() {
        System.out.println("Enter course name: ");
        String courseName = scan.nextLine();
        System.out.println("Does the course round? (y/n)");
        String round = scan.nextLine();
        boolean rounding = false;
        if(round.equals("y")) {
            rounding = true;
        }
        if(round.equals("n")) {
            rounding = false;
        }
        else if(!round.equals("n") && !round.equals("y")) {
            System.out.println("Invalid input");
        }
        double roundedPercentage = 0.0;
        if(rounding){
            System.out.println("How much is rounded?\ne.g., .5 will round the class by +.5%");
            roundedPercentage = scan.nextDouble();
            scan.nextLine();
        }
        Course course = new Course(courseName, roundedPercentage);
        this.courses.put(courseName, course);
        notifyObservers();
        System.out.print("Your new course is: ");
        System.out.println(course.displayCourse());
    }

    public void deleteCourse(Course course) {
        courses.remove(course.getName());
        notifyObservers();
    }

    public String displayCourse(Course course){
        return course.displayCourse();
    }

    public String displayAllCourses() {
        String result = ("\nCourse List:\n");
        for (String s : courses.keySet()) {
            Course course = courses.get(s);
            result += course.displayCourse();
        }
        return result.toString();
    }

    public void editCourse() {
        System.out.println(displayAllCourses());
        System.out.println("Enter course to edit");
        String courseName = scan.nextLine();
        if(this.courses.containsKey(courseName)){
            Course course = this.courses.get(courseName);
            String input;
            do {
                System.out.println("\nEditing course: " + course.getName());
                System.out.println(displayCourse(course));
                System.out.println("1 - Input Categories");
                System.out.println("2 - Input Category Assignment Information");
                System.out.println("r - return to menu");
                input = scan.nextLine();
                switch (input) {
                    case "1":
                        inputCategory(course);
                        break;
                    case "2":
                        inputCategoryAssignmentInfo(course);
                        break;
                    case "r":
                        break;
                    default:
                        System.out.println("Invalid option, please try again");
                }
            }while (!input.equals("r")) ;
        }
        else{
            System.out.println("Invalid input");
        }
    }

    public void inputCategory(Course course){
        this.courses.get(course.getName()).addCategories();
        notifyObservers();
    }

    public void inputCategoryAssignmentInfo(Course course){
        this.courses.get(course.getName()).editCategories();
        notifyObservers();
    }

    public void addObserver(Observer observer) {
        observers.add(observer);
    }

    public void removeObserver(Observer observer) {
        observers.remove(observer);
    }

    public void notifyObservers() {
        for (Observer observer : observers) {
            observer.update();
        }
    }

}