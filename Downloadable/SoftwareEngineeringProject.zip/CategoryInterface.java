package TNTFC;

public interface CategoryInterface {
    public String getName();
    public double getWeight();
    public String displayCategory();
    public String displayAllAssignments();
    public void addAssignment(Assignment assignment);
    public void addAssignments();
    public void editAssignmentGrades();
    public double editPotentialAssignmentGrades();
}
