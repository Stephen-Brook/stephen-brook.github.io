package TNTFC;

public interface Observer {
    void update();
}